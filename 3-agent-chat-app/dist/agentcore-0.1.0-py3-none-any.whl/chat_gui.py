import boto3
import json
import gradio as gr
import uuid
import datetime
from boto3.session import Session
from botocore.exceptions import ClientError

# --- מעקף הגדרות מקומי במקום AWS SSM ---
# הגדרת הודעת הפתיחה בנפרד כדי למנוע בעיות סינטקס
msg = "שלום! אני הסוכן החכם למיצוי זכויות באגף השיקום. כדי שאוכל לתת לך את המידע המדויק ביותר, אשמח לדעת: 1. מאיזה עיר? 2. אחוזי נכות? 3. נושא לבירור? 4. מספר פנייה?"

LOCAL_PARAMS = {
    "team_name": "SHIKUM",
    "application_name": "סוכן מיצוי זכויות - אגף השיקום",
    "application_description": "הסוכן החכם למיצוי זכויות והכוונת זכאים בשיקום",
    "application_examples": "נפצעתי ברגליים ואני מתקשה להתנייד. מה מגיע לי?,מה הסטטוס של פנייה מספר CLM-1001?",
    "agent_arn": "arn:aws:bedrock-agentcore:us-west-2:223609046142:runtime/kb_agent-n2PpEEA2Oc",
    "introductory_message": msg,
    "logo_path": "",
    "account_email": "",
    "account_message": "",
    "voting_url": ""
}

def retrieve_parameter_value(ssm_client, parameter_name: str) -> str:
    """מושך את ההגדרות מהמילון המקומי שלנו במקום לפנות ל-AWS שחוסם אותנו"""
    if parameter_name in LOCAL_PARAMS and LOCAL_PARAMS[parameter_name]:
        return LOCAL_PARAMS[parameter_name]
    raise ClientError({"Error": {"Code": "ParameterNotFound", "Message": "Mock error"}}, "GetParameter")

# ── AWS clients ────────────────────────────────────────────────────────────────
boto_session   = Session()
region         = "eu-north-1" # מקובע לאזור של הסוכן שלך
ssm_client     = boto3.client('ssm', region_name=region)
agentcore_client = boto3.client('bedrock-agentcore', region_name=region)

# ── SSM parameters ─────────────────────────────────────────────────────────────
agent_arn = retrieve_parameter_value(ssm_client, "agent_arn")

try:
    introductory_message = retrieve_parameter_value(ssm_client, "introductory_message")
    print(f"[Info] Introductory message found: {introductory_message[:50]}...")
except ClientError:
    introductory_message = "Hello! I am your AI assistant. How can I help you today?"
    print("[Info] Introductory message parameter not found - using default")

try:
    account_email = retrieve_parameter_value(ssm_client, "account_email")
    print(f"[Info] Account email found: {account_email}")
except ClientError:
    account_email = ""
    print("[Info] Account email parameter not found")

try:
    account_message = retrieve_parameter_value(ssm_client, "account_message")
    print(f"[Info] Account message found: {account_message[:50]}...")
except ClientError:
    account_message = "Hello, I'd like to schedule a GenAI discovery meeting."
    print("[Info] Account message parameter not found")

try:
    logo_path = retrieve_parameter_value(ssm_client, "logo_path")
    print(f"[Info] Logo parameter found: {logo_path}")
except ClientError:
    logo_path = ""
    print("[Info] Logo parameter not found")

try:
    _initial_voting_url = retrieve_parameter_value(ssm_client, "voting_url")
    print(f"[Info] Voting URL found: {_initial_voting_url}")
except ClientError:
    _initial_voting_url = ""
    print("[Info] Voting URL not set")

# ── Session management ─────────────────────────────────────────────────────────
current_session_id = str(uuid.uuid4()).replace('-', '') + str(uuid.uuid4()).replace('-', '')[:5]
chat_sessions      = {}
initial_history    = [{"role": "assistant", "content": introductory_message}]

def generate_session_id():
    return str(uuid.uuid4()).replace('-', '') + str(uuid.uuid4()).replace('-', '')[:5]

def get_session_title(first_message):
    return first_message[:30] + "..." if len(first_message) > 30 else first_message

def get_session_choices():
    if not chat_sessions:
        return []
    choices = []
    for sid, data in sorted(chat_sessions.items(), key=lambda x: x[1]["created"], reverse=True):
        choices.append(f"{data['created'].strftime('%H:%M')} - {data['title']}")
    return choices

def start_new_chat():
    global current_session_id
    current_session_id = generate_session_id()
    print(f"[Chat] New session: {current_session_id}")
    return initial_history, "", gr.Radio(choices=get_session_choices(), value=None)

def load_chat_session(session_selection):
    global current_session_id
    if not session_selection or session_selection == "No previous chats":
        return initial_history, ""
    try:
        selected_title = session_selection.split(" - ", 1)[1]
        for sid, data in chat_sessions.items():
            if data["title"] == selected_title:
                current_session_id = sid
                history = data["history"].copy()
                if not history or history[0].get("content") != introductory_message:
                    history.insert(0, {"role": "assistant", "content": introductory_message})
                return history, ""
    except:
        pass
    return initial_history, ""

def save_chat_message(message, response):
    global current_session_id, chat_sessions
    if current_session_id not in chat_sessions:
        chat_sessions[current_session_id] = {
            "history": [],
            "title": get_session_title(message),
            "created": datetime.datetime.now()
        }
    chat_sessions[current_session_id]["history"].extend([
        {"role": "user",      "content": message},
        {"role": "assistant", "content": response}
    ])

def chat_with_agent_simple(message, history):
    try:
        print(f"\n[Chat] Sending message | Session: {current_session_id}")
        boto3_response = agentcore_client.invoke_agent_runtime(
            agentRuntimeArn=agent_arn,
            qualifier="DEFAULT",
            runtimeSessionId=current_session_id,
            payload=json.dumps({"prompt": message})
        )
        accumulated_bytes = b""
        event_count = 0
        for event in boto3_response.get("response", []):
            event_count += 1
            accumulated_bytes += event
        try:
            event_data = accumulated_bytes.decode('utf-8')
        except UnicodeDecodeError:
            event_data = accumulated_bytes.decode('utf-8', errors='replace')
            print("[Warning] UTF-8 decoding issue")
        try:
            data = json.loads(event_data)
            if isinstance(data, dict) and 'content' in data:
                full_response = "".join(item['text'] for item in data['content'])
            else:
                full_response = str(data)
        except json.JSONDecodeError:
            full_response = event_data
        print(f"[Chat] Processed {event_count} events")
        if full_response:
            full_response = full_response.replace('\\n', '\n')
            save_chat_message(message, full_response.strip())
            return full_response.strip()
        return "No response received from agent"
    except Exception as e:
        print(f"[Chat] Error: {e}")
        return f"Error connecting to agent: {str(e)}"

# ── RTL CSS ────────────────────────────────────────────────────────────────────
RTL_CSS = """<style id="rtl-style">
.gradio-container { direction: rtl; text-align: right; }
.message-wrap, .message { direction: rtl; text-align: right; unicode-bidi: plaintext; }
.chatbot .message-bubble-border, .chatbot .message-bubble { direction: rtl; text-align: right; }
textarea, input[type="text"] { direction: rtl; text-align: right; unicode-bidi: plaintext; }
.md, .markdown-text, .prose { direction: rtl; text-align: right; unicode-bidi: plaintext; }
.md ul, .md ol, .prose ul, .prose ol { padding-right: 1.5em; padding-left: 0; }
.app-header { direction: ltr; }
.mvp-footer { direction: rtl; }
.chat-history { direction: rtl; text-align: right; }
.examples-row button { direction: rtl; text-align: right; }
</style>"""
REMOVE_RTL_CSS = """<style id="rtl-style"></style>"""

def toggle_rtl(current_label):
    if "Off" in current_label:
        return RTL_CSS, "🔤 RTL On"
    return REMOVE_RTL_CSS, "🔤 RTL Off"

# ── Contact link ───────────────────────────────────────────────────────────────
contact_value = account_email.strip()
if contact_value.startswith("http://") or contact_value.startswith("https://"):
    contact_link   = contact_value
    link_attrs     = 'target="_blank" rel="noopener noreferrer"'
elif contact_value:
    contact_link   = f"mailto:{contact_value}?subject=GenAI Discovery Meeting&body={account_message}"
    link_attrs     = ''
else:
    contact_link   = ""
    link_attrs     = ""


# ── CSS ────────────────────────────────────────────────────────────────────────
custom_css = """
/* ── Fonts ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap');

/* ── Reset & base ── */
*, *::before, *::after { box-sizing: border-box; }
html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
}
:root,
:root.dark,
.dark {
    color-scheme: light !important;
    --body-background-fill: #f8f9fc !important;
    --body-text-color: #1a1a2e !important;
    --background-fill-primary: #ffffff !important;
    --background-fill-secondary: #f8f9fc !important;
    --border-color-primary: #e8ecf0 !important;
    --color-accent: #ff9900 !important;
    --chatbot-background: #ffffff !important;
    --message-background-fill: #f0f7ff !important;
    --input-background-fill: #ffffff !important;
    --input-text-color: #1a1a2e !important;
    --block-background-fill: #ffffff !important;
    --block-label-background-fill: #ffffff !important;
    --panel-background-fill: #ffffff !important;
    --table-even-background-fill: #f8f9fc !important;
    --table-odd-background-fill: #ffffff !important;
    --neutral-950: #1a1a2e !important;
    --neutral-900: #2d2d3d !important;
    --neutral-800: #3d3d4d !important;
}
.gradio-container {
    font-family: 'Inter', system-ui, -apple-system, sans-serif !important;
    background: #f8f9fc !important;
    max-width: 100% !important;
    padding-top: 52px !important;
    padding-bottom: 44px !important;
}
footer { display: none !important; }
.app-header {
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1001;
    background: linear-gradient(135deg, #0f1923 0%, #1a2d45 60%, #0f2a4a 100%);
    padding: 10px 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    height: 52px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.2);
}
.app-header img {
    height: 30px;
    width: auto;
    object-fit: contain;
}
.app-header .header-divider {
    width: 1px; height: 24px;
    background: rgba(255,255,255,0.2);
}
.app-header .header-title {
    color: #fff;
    font-size: 15px;
    font-weight: 600;
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.app-header .header-badge {
    background: rgba(255,153,0,0.15);
    border: 1px solid rgba(255,153,0,0.4);
    color: #ff9900;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 20px;
    white-space: nowrap;
}
.sidebar-toggle { display: none; }
.mvp-footer {
    position: fixed;
    bottom: 0; left: 0; right: 0;
    z-index: 1001;
    background: linear-gradient(135deg, #0f1923 0%, #1a2d45 100%);
    padding: 8px 20px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 -2px 12px rgba(0,0,0,0.2);
}
.sidebar-panel {
    background: #ffffff;
    border-right: 1px solid #e8ecf0;
    padding: 16px 12px;
    overflow-y: auto;
}
.new-chat-btn {
    width: 100%;
    background: linear-gradient(135deg, #ff9900, #e88a00) !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 9px 14px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    margin-bottom: 6px !important;
}
.rtl-btn {
    width: 100%;
    background: transparent !important;
    color: #64748b !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 8px !important;
    padding: 6px 14px !important;
    font-size: 12px !important;
    cursor: pointer !important;
    margin-bottom: 12px !important;
}
.chat-main {
    background: #f8f9fc;
    padding: 0 !important;
}
.chatbot {
    background: #ffffff !important;
    border: 1px solid #e8ecf0 !important;
    border-radius: 12px !important;
}
.message.bot { background: #f0f7ff !important; border-radius: 12px 12px 12px 2px !important; }
.message.user {
    background: linear-gradient(135deg, #0f2a4a, #1a3d5c) !important;
    color: #fff !important;
    border-radius: 12px 12px 2px 12px !important;
}
.message.user .md, .message.user p { color: #fff !important; }
.input-container textarea {
    border-radius: 10px !important;
    border: 1.5px solid #e2e8f0 !important;
    font-size: 14px !important;
    padding: 10px 14px !important;
    background: #fff !important;
    resize: none !important;
}
.submit-button {
    background: linear-gradient(135deg, #ff9900, #e88a00) !important;
    border-radius: 8px !important;
    color: white !important;
    padding: 8px !important;
}
"""

# ── App name & description ─────────────────────────────────────────────────────
app_name        = retrieve_parameter_value(ssm_client, "application_name")
app_description = retrieve_parameter_value(ssm_client, "application_description")
app_examples    = [item.strip() for item in retrieve_parameter_value(ssm_client, "application_examples").split(',')]

# ── Build header HTML ──────────────────────────────────────────────────────────
aws_logo_html = '<img src="https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg" alt="AWS" style="height:28px;width:auto;filter:brightness(0)invert(1)">'
partner_logo_html = f'<span style="background:#fff;border-radius:6px;padding:3px 8px;display:inline-flex;align-items:center"><img src="{logo_path}" alt="Partner" style="height:24px;width:auto;object-fit:contain;display:block"></span>' if logo_path else ''
divider_html  = '<div class="header-divider"></div>' if logo_path else ''

header_html = f"""
<div class="app-header">
    <button class="sidebar-toggle" onclick="
        var s = document.querySelector('.sidebar-panel');
        if(s) s.classList.toggle('open');
    ">☰</button>
    {aws_logo_html}
    {divider_html}
    {partner_logo_html}
    <div class="header-title">{app_name}</div>
    <div class="header-badge">Powered by AWS AgentCore</div>
</div>
"""

# ── Build footer HTML ──────────────────────────────────────────────────────────
footer_html = f"""
<div class="mvp-footer">
    <p><span class="footer-text" style="color:rgba(255,255,255,0.9)!important">🚀 מערכת מיצוי זכויות לאגף השיקום</span></p>
</div>
"""

# ── Gradio layout ──────────────────────────────────────────────────────────────
with gr.Blocks(title=app_name) as demo:

    gr.HTML(header_html)
    with gr.Row():
        with gr.Column(scale=1, elem_classes=["sidebar-panel"]):
            gr.HTML('<div class="sidebar-section-label">Conversations</div>')
            new_chat_btn = gr.Button("＋  New Chat", elem_classes=["new-chat-btn"], size="sm")
            rtl_css_block = gr.HTML(value="", visible=True)
            rtl_btn = gr.Button("🔤 RTL Off", elem_classes=["rtl-btn"], size="sm", variant="secondary")
            rtl_btn.click(fn=toggle_rtl, inputs=[rtl_btn], outputs=[rtl_css_block, rtl_btn])

            session_list = gr.Radio(choices=[], value=None, label="Previous Chats", interactive=True)

        with gr.Column(scale=4, elem_classes=["chat-main"]):
            chat_interface = gr.ChatInterface(
                fn=chat_with_agent_simple,
                title=app_name,
                description=app_description,
                examples=app_examples,
                autoscroll=True,
                chatbot=gr.Chatbot(height=480, render_markdown=True, value=initial_history, show_label=False)
            )

    gr.HTML(footer_html)

    new_chat_btn.click(fn=start_new_chat, inputs=[], outputs=[chat_interface.chatbot, chat_interface.textbox, session_list])
    session_list.change(fn=load_chat_session, inputs=[session_list], outputs=[chat_interface.chatbot, chat_interface.textbox])

if __name__ == "__main__":
    print("=" * 60)
    print("Starting Bedrock Agent Chat Interface")
    print("=" * 60)
    print(f"Region:    {region}")
    print(f"Agent ARN: {agent_arn}")
    print(f"Server:    http://0.0.0.0:8084")
    print("=" * 60)
    print("\nChat interface ready. Open your browser to start chatting.")
    demo.launch(share=False, server_name="0.0.0.0", server_port=8084, css=custom_css)